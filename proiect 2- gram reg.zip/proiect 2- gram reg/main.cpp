#include <iostream>
#include <fstream>
#include <unordered_map>
#include <vector>
using namespace std;
ifstream f("gram_reg.in");
string tranz[10000]; //retin tranzitiile pe parcurs
int n;
unordered_map<string, vector<string>> productii;

void afisterm(int m)
{   for (int i=0; i<=m; i++)
        if(tranz[i][0]!='*' && tranz[i][0]!='#') // daca nu e tranzitie simpla sau cuvantul vid are obligatoriu terminal in ea
            cout<<tranz[i][0]<<" ";
        cout<<"\n";
}

bool continelitera(string test, char litera){ // functie care verifica daca un string contine o litera, o folosim
    int i=0;                                  // ca sa vedem daca daca un element din tranz e terminal (verific
                                             // sa nu contina '*' adica sa nu fie neterminal

    while (i++<test.size())
    {
        if (test[i]==litera)
            return true;
    }
    return false;
}

int nrterm(int y) //functie care calculeaza numarul de terminale curent
{
    int nr=0;
    for (int i=0; i<=y; i++)
    {
        if(tranz[i][0]!='*' && tranz[i]!="#")   // parcurg toate tranzitiile de pana acum  si tranzitiile cu neterminale simple
                                                // (adica fara terminal in fata) sau cuvantul vid le ignor
            nr ++;

    }
    return nr;
}

void bkt(int k) //functie backtracking pentru gasirea solutiilor
{
    if(tranz[k - 1][0]=='*' && nrterm(k-1)<= n) //cazul in care pe un nivel din tranz este un neterminal si nu am ajuns la nr de litere dorit
            for(int i=0; i<productii[tranz[k-1]].size(); i++)
            {
                tranz[k]=productii[tranz[k-1]][i];     // iau pe rand toate productiile, si apelez recursiv pentru fiecare neterminal din productia curenta
                bkt(k+1);
            }
   else{
        if(tranz[k-1].length()>=2 && nrterm(k-1)<=n && tranz[k-1][1]=='*') //cazul in care pe un nivel din tranz este o litera + un neterminal si
                                                                            //nu am ajuns la nr de litere dorit
        for(int i=0; i<productii[tranz[k-1].substr(1,2)].size(); i++)
            {
                tranz[k]=productii[tranz[k-1].substr(1,2)][i];
                bkt(k+1);
            }
    }

    if (nrterm(k-1)==n && continelitera(tranz[k-1],'*')==false) //cazul in care am ajuns la numarul de litere dorit si nu este un neterminal
            afisterm(k - 1); //afisam cuvantul
}

int main()
{
    string a, b;
    while (f>>a>>b) //citesc din fisier
        productii[a].push_back(b); //si completez map-ul care contine productiile
    cout<<"n= ";
    cin>>n;
    tranz[0]="*S"; //marchez in tranz punctul de plecare, adica simbolul de start
    bkt(1); //apelez functia de backtracking
    return 0;
}

